// Consultation form -> opens WhatsApp with a ready-made message (no server needed).
(function () {
  var PHONE = "966506935963";
  var form = document.getElementById("lead-form");
  var error = document.getElementById("form-error");
  document.getElementById("year").textContent = new Date().getFullYear();

  // floating WhatsApp button appears once the hero's own buttons have scrolled out of view
  var fab = document.querySelector(".fab"), cta = document.querySelector(".hero .cta-row");
  if ("IntersectionObserver" in window && fab && cta) {
    new IntersectionObserver(function (entries) {
      fab.classList.toggle("is-visible", !entries[0].isIntersecting);
    }).observe(cta);
  } else if (fab) {
    fab.classList.add("is-visible");
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var d = new FormData(form);
    var name = (d.get("name") || "").trim();
    if (!name) {
      error.hidden = false;
      form.elements.name.focus();
      return;
    }
    error.hidden = true;
    var lines = [
      "محاسبة",
      "الاسم: " + name,
      d.get("activity") ? "النشاط: " + d.get("activity").trim() : "",
      "الخدمة: " + d.get("service"),
      "طريقة العمل: " + d.get("mode"),
      d.get("notes") ? "ملاحظات: " + d.get("notes").trim() : ""
    ].filter(Boolean);
    window.open("https://wa.me/" + PHONE + "?text=" + encodeURIComponent(lines.join("\n")), "_blank", "noopener");
  });
})();
