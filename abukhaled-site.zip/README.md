# موقع أبو خالد – محاسب عام بجدة

صفحة واحدة ثابتة (HTML/CSS/JS) بدون خادم، عربية RTL، متوافقة مع الجوال.
نموذج طلب الاستشارة يفتح واتساب برسالة جاهزة، فلا يحتاج قاعدة بيانات.

## التشغيل محليًا
افتح `index.html` في المتصفح، أو: `python3 -m http.server` داخل هذا المجلد.

## النشر
الأسهل أن يكون للموقع مستودع مستقل (مثل `abukhaled-site`) يحتوي محتويات هذا المجلد فقط، ثم:
**Settings → Pages → Deploy from a branch → main / (root)**
فيظهر الرابط: `https://<اسم-الحساب>.github.io/abukhaled-site/`.
ويمكن لاحقًا ربط نطاق خاص من **Settings → Pages → Custom domain**.

## التعديل
- الرقم والبريد في `index.html` و`script.js` (المتغير `PHONE`).
- الفيديو `assets/ad.mp4` وغلافه `assets/ad-poster.jpg`.
